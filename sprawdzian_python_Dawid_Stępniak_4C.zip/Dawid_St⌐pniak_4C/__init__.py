__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Dawid Stępniak 4C"