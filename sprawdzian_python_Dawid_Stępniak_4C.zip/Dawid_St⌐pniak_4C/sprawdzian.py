__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Dawid Stępniak 4C"

import json
from datetime import datetime
from models.Student import Student
from models.Teacher import Teacher
from models.Subject import Subject
from models.Grades import Grades
from year_grade import year_grade

teachers = []
subjects = []
students = []
grades = []

with open('teachers.txt', 'r') as file:
    for line in file:
        _id, name, surname = line.strip().split()
        teachers.append(Teacher(int(_id), name, surname))

with open('subjects.txt', 'r') as file:
    for line in file:
        _id, name, teacher_id = line.strip().split()
        teacher = next((t for t in teachers if t._id == int(teacher_id)), None)
        if teacher:
            subjects.append(Subject(int(_id), name, teacher))

with open('students.txt', 'r') as file:
    for line in file:
        _id, first_name, last_name, birth_date = line.strip().split()
        birth_date = datetime.strptime(birth_date, '%Y-%m-%d').date()
        students.append(Student(int(_id), first_name, last_name, birth_date))

with open('grades.txt', 'r') as file:
    for line in file:
        student_id, subject_id, *grades_list = line.strip().split()
        student = next((s for s in students if s._id == int(student_id)), None)
        subject = next((sub for sub in subjects if sub._id == int(subject_id)), None)
        if student and subject:
            grades_obj = Grades(student, subject)
            grades_obj.grades = list(map(int, grades_list[0].split(',')))
            grades.append(grades_obj)

print("Oceny i średnie poszczególnych uczniów:")
for student in students:
    print(f"{student}:")
    for subject in subjects:
        subject_grades = next((g for g in grades if g.student == student and g.subject == subject), None)
        if subject_grades:
            average = subject_grades.get_average()
            final_grade = year_grade(average)
            print(f"{subject.name}:")
            print(f"Oceny: {', '.join(map(str, subject_grades.grades))}")
            print(f"Średnia: {average:.2f}")
            print(f"Ocena końcowa: {final_grade}")
    print()

students_data = []
for student in students:
    student_info = {str(student): {}}
    for subject in subjects:
        subject_grades = next((g for g in grades if g.student == student and g.subject == subject), None)
        if subject_grades:
            average = round(subject_grades.get_average(), 2)
            final_grade = year_grade(average)
            student_info[str(student)][subject.name] = {
                "Oceny": ', '.join(map(str, subject_grades.grades)),
                "Srednia": average,
                "Ocena roczna": final_grade
            }
    students_data.append(student_info)

with open('students.json', 'w') as f:
    json.dump(students_data, f, indent=4)

subjects_data = []
for subject in subjects:
    subject_grades_list = [g for g in grades if g.subject == subject]
    all_grades = [grade for g in subject_grades_list for grade in g.get_grades()]
    average = round(sum(all_grades) / len(all_grades), 2) if all_grades else 0
    subject_info = {
        subject.name: {
            "Nauczyciel": str(subject.teacher),
            "Oceny": all_grades,
            "Średnia": average
        }
    }
    subjects_data.append(subject_info)

with open('subjects.json', 'w') as f:
    json.dump(subjects_data, f, indent=4)

print("=" * 50)
print()

for subject in subjects:
    subject_grades_list = [g for g in grades if g.subject == subject]
    all_grades = [grade for g in subject_grades_list for grade in g.get_grades()]
    average = round(sum(all_grades) / len(all_grades), 2) if all_grades else 0
    print(f"{subject.name}:")
    print(f"Nauczyciel: {subject.teacher}")
    print(f"Oceny: {', '.join(map(str, all_grades))}")
    print(f"Średnia: {average:.2f}")
    print()